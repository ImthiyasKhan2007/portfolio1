import { createFileRoute } from "@tanstack/react-router";
import { Code, Palette, Users, BookOpen, Award, Heart } from "lucide-react";
import developerPortrait from "@/assets/developer-portrait.jpg";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — John Doe | Web Developer" },
      { name: "description", content: "Learn about John Doe, a passionate Front-End Developer with expertise in HTML5, CSS3, JavaScript, and web accessibility." },
      { property: "og:title", content: "About — John Doe | Web Developer" },
      { property: "og:description", content: "Learn about John Doe, a passionate Front-End Developer with expertise in HTML5, CSS3, JavaScript, and web accessibility." },
      { property: "og:url", content: "/about" },
    ],
    links: [{ rel: "canonical", href: "/about" }],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <div>
      {/* Page Header */}
      <section className="border-b border-border/50 bg-surface py-16">
        <div className="mx-auto max-w-5xl px-4 text-center">
          <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-5xl">
            About Me
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-lg text-muted-foreground">
            Passionate developer crafting accessible, performant web experiences.
          </p>
        </div>
      </section>

      {/* Bio */}
      <section aria-labelledby="bio-title" className="bg-background py-20">
        <div className="mx-auto max-w-5xl px-4">
          <div className="grid gap-12 lg:grid-cols-2 lg:items-center">
            <div>
              <h2
                id="bio-title"
                className="text-2xl font-bold tracking-tight text-foreground"
              >
                My Story
              </h2>
              <div className="mt-6 space-y-4 text-muted-foreground leading-relaxed">
                <p>
                  I'm a Front-End Developer who believes the web should work for
                  everyone. With a deep foundation in semantic HTML5, modern CSS3,
                  and vanilla JavaScript, I build interfaces that are both
                  beautiful and inclusive.
                </p>
                <p>
                  My approach centers on accessibility-first design — ensuring that
                  every user, regardless of device or ability, can navigate and
                  interact with the sites I build. I follow WCAG guidelines
                  closely and test with screen readers and keyboard-only
                  navigation.
                </p>
                <p>
                  When I'm not coding, I'm exploring new web standards,
                  contributing to open-source accessibility projects, and sharing
                  knowledge with the developer community.
                </p>
              </div>
            </div>
            <div className="flex items-center justify-center">
              <div className="relative">
                <div className="absolute -inset-3 rounded-3xl bg-gradient-to-br from-brand/30 to-primary/20 blur-xl" aria-hidden="true" />
                <img
                  src={developerPortrait}
                  alt="Portrait of John Doe, Front-End Developer, working at his desk"
                  width={768}
                  height={768}
                  loading="lazy"
                  className="relative h-72 w-72 rounded-2xl object-cover shadow-lg ring-1 ring-border sm:h-80 sm:w-80"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section aria-labelledby="values-title" className="bg-surface py-20">
        <div className="mx-auto max-w-5xl px-4">
          <div className="mb-12 text-center">
            <h2
              id="values-title"
              className="text-3xl font-bold tracking-tight text-foreground"
            >
              What I Stand For
            </h2>
          </div>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            <ValueCard
              icon={<Heart className="h-6 w-6" />}
              title="Accessibility First"
              description="Every interface must work for everyone. I build with WCAG standards from day one, not as an afterthought."
            />
            <ValueCard
              icon={<Code className="h-6 w-6" />}
              title="Clean Code"
              description="Readable, maintainable code that stands the test of time. I write code for humans, not just machines."
            />
            <ValueCard
              icon={<Palette className="h-6 w-6" />}
              title="Thoughtful Design"
              description="Beautiful interfaces that enhance usability without sacrificing performance or accessibility."
            />
            <ValueCard
              icon={<BookOpen className="h-6 w-6" />}
              title="Continuous Learning"
              description="Web standards evolve constantly. I stay current with emerging technologies and best practices."
            />
            <ValueCard
              icon={<Award className="h-6 w-6" />}
              title="Quality Craft"
              description="Attention to every detail — from semantic HTML structure to pixel-perfect CSS and smooth interactions."
            />
            <ValueCard
              icon={<Users className="h-6 w-6" />}
              title="User-Centered"
              description="I design and build with real users in mind, testing across devices and assistive technologies."
            />
          </div>
        </div>
      </section>
    </div>
  );
}

function ValueCard({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <div className="rounded-xl border border-border bg-card p-6 transition-all hover:border-primary/20 hover:shadow-md">
      <div className="mb-4 inline-flex items-center justify-center rounded-lg bg-brand-muted p-3 text-brand">
        {icon}
      </div>
      <h3 className="text-lg font-semibold text-card-foreground">{title}</h3>
      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
        {description}
      </p>
    </div>
  );
}
