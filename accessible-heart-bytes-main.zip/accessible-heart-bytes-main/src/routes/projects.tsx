import { createFileRoute } from "@tanstack/react-router";
import { ExternalLink, Github, Code, Sparkles } from "lucide-react";
import projectPortfolio from "@/assets/project-portfolio.jpg";
import projectTaskmanager from "@/assets/project-taskmanager.jpg";

export const Route = createFileRoute("/projects")({
  head: () => ({
    meta: [
      { title: "Projects — John Doe | Web Developer" },
      { name: "description", content: "Explore projects by John Doe, featuring accessible, responsive web applications built with modern technologies." },
      { property: "og:title", content: "Projects — John Doe | Web Developer" },
      { property: "og:description", content: "Explore projects by John Doe, featuring accessible, responsive web applications built with modern technologies." },
      { property: "og:url", content: "/projects" },
    ],
    links: [{ rel: "canonical", href: "/projects" }],
  }),
  component: ProjectsPage,
});

function ProjectsPage() {
  const projects = [
    {
      title: "Portfolio Website",
      description:
        "A fully responsive portfolio built with semantic HTML5 and accessibility best practices. Features keyboard navigation, ARIA landmarks, and screen reader optimization.",
      tags: ["HTML5", "CSS3", "Accessibility", "Responsive"],
      icon: <Code className="h-6 w-6" />,
      image: projectPortfolio,
    },
    {
      title: "Task Manager App",
      description:
        "Productivity application developed using JavaScript. Includes task creation, editing, filtering, and local storage persistence with a clean, intuitive interface.",
      tags: ["JavaScript", "UI/UX", "Local Storage", "Responsive"],
      icon: <Sparkles className="h-6 w-6" />,
      image: projectTaskmanager,
    },
    {
      title: "Accessible Form Builder",
      description:
        "A drag-and-drop form builder that generates WCAG-compliant forms. Includes live validation, error announcement regions, and keyboard-only operation support.",
      tags: ["HTML5", "JavaScript", "ARIA", "Accessibility"],
      icon: <ExternalLink className="h-6 w-6" />,
      image: null,
    },
    {
      title: "Component Library",
      description:
        "A reusable UI component library focused on accessibility. Each component is tested with screen readers and includes proper focus management.",
      tags: ["CSS3", "JavaScript", "Design System", "A11y"],
      icon: <Github className="h-6 w-6" />,
      image: null,
    },
  ];

  return (
    <div>
      {/* Page Header */}
      <section className="border-b border-border/50 bg-surface py-16">
        <div className="mx-auto max-w-5xl px-4 text-center">
          <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-5xl">
            Projects
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-lg text-muted-foreground">
            A collection of projects showcasing my skills in front-end
            development, accessibility, and responsive design.
          </p>
        </div>
      </section>

      {/* Projects Grid */}
      <section aria-labelledby="projects-list-title" className="bg-background py-20">
        <div className="mx-auto max-w-5xl px-4">
          <h2 id="projects-list-title" className="sr-only">
            Project List
          </h2>
          <div className="grid gap-8 md:grid-cols-2">
            {projects.map((project) => (
              <article
                key={project.title}
                className="group flex flex-col overflow-hidden rounded-xl border border-border bg-card transition-all hover:border-primary/20 hover:shadow-md"
              >
                {project.image ? (
                  <div className="aspect-[4/3] overflow-hidden bg-surface">
                    <img
                      src={project.image}
                      alt={`${project.title} preview`}
                      width={800}
                      height={600}
                      loading="lazy"
                      className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                  </div>
                ) : (
                  <div className="flex aspect-[4/3] items-center justify-center bg-gradient-to-br from-hero-bg to-primary text-primary-foreground transition-colors">
                    <div className="text-center">
                      <div className="mx-auto mb-2 inline-flex items-center justify-center rounded-lg bg-brand-muted p-3 text-brand">
                        {project.icon}
                      </div>
                      <span className="text-sm font-medium">{project.title}</span>
                    </div>
                  </div>
                )}
                <div className="flex flex-grow flex-col p-6">
                <h3 className="text-xl font-semibold text-card-foreground">
                  {project.title}
                </h3>
                <p className="mt-2 flex-grow text-sm leading-relaxed text-muted-foreground">
                  {project.description}
                </p>
                <div className="mt-4 flex flex-wrap gap-2">
                  {project.tags.map((tag) => (
                    <span
                      key={tag}
                      className="rounded-full bg-secondary px-3 py-1 text-xs font-medium text-secondary-foreground"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
                <div className="mt-6 flex gap-3">
                  <button className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90">
                    <ExternalLink className="h-4 w-4" />
                    Live Demo
                  </button>
                  <button className="inline-flex items-center gap-2 rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent">
                    <Github className="h-4 w-4" />
                    Source Code
                  </button>
                </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
