import { createFileRoute, Link } from "@tanstack/react-router";
import { Code, Globe, Accessibility, Zap, ArrowRight } from "lucide-react";
import projectPortfolio from "@/assets/project-portfolio.jpg";
import projectTaskmanager from "@/assets/project-taskmanager.jpg";
import developerPortrait from "@/assets/developer-portrait.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "John Doe | Front-End Web Developer" },
      { name: "description", content: "Portfolio of John Doe, Front-End Developer specializing in accessible, responsive, and user-friendly websites." },
      { name: "keywords", content: "portfolio, web developer, HTML5, CSS3, JavaScript, accessibility" },
      { property: "og:title", content: "John Doe | Front-End Web Developer" },
      { property: "og:description", content: "Portfolio of John Doe, Front-End Developer specializing in accessible, responsive, and user-friendly websites." },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: HomePage,
});

function HomePage() {
  return (
    <div>
      {/* Hero Section */}
      <section
        aria-labelledby="hero-title"
        className="relative overflow-hidden bg-hero-bg py-24 text-primary-foreground"
      >
        {/* Decorative glows */}
        <div className="pointer-events-none absolute -right-24 -top-24 h-96 w-96 rounded-full bg-brand/20 blur-3xl" aria-hidden="true" />
        <div className="pointer-events-none absolute -bottom-32 -left-24 h-96 w-96 rounded-full bg-primary/20 blur-3xl" aria-hidden="true" />
        <div className="relative mx-auto grid max-w-5xl items-center gap-12 px-4 lg:grid-cols-2">
          <div className="text-center lg:text-left">
            <p className="mb-3 text-sm font-medium tracking-wider text-brand">
              WELCOME TO MY PORTFOLIO
            </p>
            <h1
              id="hero-title"
              className="text-4xl font-bold leading-tight tracking-tight sm:text-5xl md:text-6xl"
            >
              Front-End Web Developer
            </h1>
            <p className="mx-auto mt-6 max-w-2xl text-lg leading-relaxed text-primary-foreground/80 lg:mx-0">
              I build accessible, responsive, and user-friendly websites using
              modern web technologies. Every pixel is crafted with care for
              performance and inclusivity.
            </p>
            <div className="mt-8 flex flex-wrap items-center justify-center gap-4 lg:justify-start">
              <Link
                to="/projects"
                className="inline-flex items-center gap-2 rounded-md bg-brand px-6 py-3 text-sm font-medium text-white transition-all hover:bg-brand/90 hover:shadow-lg"
              >
                View Projects
                <ArrowRight className="h-4 w-4" />
              </Link>
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 rounded-md border border-primary-foreground/20 bg-transparent px-6 py-3 text-sm font-medium text-primary-foreground transition-all hover:bg-primary-foreground/10"
              >
                Get in Touch
              </Link>
            </div>
            {/* Quick stats */}
            <dl className="mt-10 flex justify-center gap-8 lg:justify-start">
              <div>
                <dt className="sr-only">Years of experience</dt>
                <dd className="text-2xl font-bold text-brand">5+</dd>
                <p className="text-xs text-primary-foreground/70">Years experience</p>
              </div>
              <div>
                <dt className="sr-only">Projects delivered</dt>
                <dd className="text-2xl font-bold text-brand">40+</dd>
                <p className="text-xs text-primary-foreground/70">Projects shipped</p>
              </div>
              <div>
                <dt className="sr-only">Accessibility score</dt>
                <dd className="text-2xl font-bold text-brand">100</dd>
                <p className="text-xs text-primary-foreground/70">A11y score</p>
              </div>
            </dl>
          </div>
          {/* Portrait */}
          <div className="flex justify-center lg:justify-end">
            <div className="relative">
              <div className="absolute -inset-4 rounded-3xl bg-gradient-to-br from-brand/40 to-primary/30 blur-2xl" aria-hidden="true" />
              <img
                src={developerPortrait}
                alt="John Doe, Front-End Developer, working at his desk"
                width={768}
                height={768}
                className="relative h-72 w-72 rounded-2xl object-cover shadow-2xl ring-1 ring-white/10 sm:h-80 sm:w-80"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section aria-labelledby="skills-title" className="bg-background py-20">
        <div className="mx-auto max-w-5xl px-4">
          <div className="mb-12 text-center">
            <h2
              id="skills-title"
              className="text-3xl font-bold tracking-tight text-foreground"
            >
              Core Technologies
            </h2>
            <p className="mt-3 text-muted-foreground">
              The tools and standards I work with every day
            </p>
          </div>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            <SkillCard
              icon={<Code className="h-6 w-6" />}
              title="HTML5 & CSS3"
              description="Semantic markup and modern styling with a focus on structure and maintainability."
            />
            <SkillCard
              icon={<Zap className="h-6 w-6" />}
              title="JavaScript"
              description="Interactive functionality and dynamic content with clean, performant code."
            />
            <SkillCard
              icon={<Accessibility className="h-6 w-6" />}
              title="Accessibility"
              description="WCAG-compliant experiences that work for everyone, regardless of ability."
            />
            <SkillCard
              icon={<Globe className="h-6 w-6" />}
              title="Responsive Design"
              description="Fluid layouts that adapt beautifully across all screen sizes and devices."
            />
          </div>
        </div>
      </section>

      {/* Featured Projects Preview */}
      <section aria-labelledby="featured-title" className="bg-surface py-20">
        <div className="mx-auto max-w-5xl px-4">
          <div className="mb-12 flex items-end justify-between">
            <div>
              <h2
                id="featured-title"
                className="text-3xl font-bold tracking-tight text-foreground"
              >
                Featured Projects
              </h2>
              <p className="mt-3 text-muted-foreground">
                A selection of recent work
              </p>
            </div>
            <Link
              to="/projects"
              className="hidden items-center gap-1 text-sm font-medium text-primary transition-colors hover:text-primary/80 sm:inline-flex"
            >
              View All
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="grid gap-6 md:grid-cols-2">
            <ProjectCard
              title="Portfolio Website"
              description="A fully responsive portfolio built with semantic HTML5 and accessibility best practices."
              tags={["HTML5", "CSS3", "Accessibility"]}
              image={projectPortfolio}
            />
            <ProjectCard
              title="Task Manager App"
              description="Productivity application developed using JavaScript with clean, maintainable code."
              tags={["JavaScript", "UI/UX", "Responsive"]}
              image={projectTaskmanager}
            />
          </div>
          <div className="mt-8 text-center sm:hidden">
            <Link
              to="/projects"
              className="inline-flex items-center gap-1 text-sm font-medium text-primary transition-colors hover:text-primary/80"
            >
              View All Projects
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section aria-labelledby="cta-title" className="bg-background py-20">
        <div className="mx-auto max-w-5xl px-4 text-center">
          <h2
            id="cta-title"
            className="text-3xl font-bold tracking-tight text-foreground"
          >
            Let's Work Together
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
            Have a project in mind? I'd love to hear about it. Let's build
            something great together.
          </p>
          <div className="mt-8">
            <Link
              to="/contact"
              className="inline-flex items-center gap-2 rounded-md bg-primary px-6 py-3 text-sm font-medium text-primary-foreground transition-all hover:bg-primary/90 hover:shadow-lg"
            >
              Get in Touch
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}

function SkillCard({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <div className="group rounded-xl border border-border bg-card p-6 transition-all hover:border-primary/20 hover:shadow-md">
      <div className="mb-4 inline-flex items-center justify-center rounded-lg bg-brand-muted p-3 text-brand transition-colors group-hover:bg-brand group-hover:text-white">
        {icon}
      </div>
      <h3 className="text-lg font-semibold text-card-foreground">{title}</h3>
      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
        {description}
      </p>
    </div>
  );
}

function ProjectCard({
  title,
  description,
  tags,
  image,
}: {
  title: string;
  description: string;
  tags: string[];
  image: string;
}) {
  return (
    <div className="group overflow-hidden rounded-xl border border-border bg-card transition-all hover:border-primary/20 hover:shadow-md">
      <div className="aspect-[4/3] overflow-hidden bg-surface">
        <img
          src={image}
          alt={`${title} project preview`}
          width={800}
          height={600}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
      </div>
      <div className="p-6">
        <h3 className="text-lg font-semibold text-card-foreground">{title}</h3>
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
          {description}
        </p>
        <div className="mt-4 flex flex-wrap gap-2">
          {tags.map((tag) => (
            <span
              key={tag}
              className="rounded-full bg-secondary px-3 py-1 text-xs font-medium text-secondary-foreground"
            >
              {tag}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
