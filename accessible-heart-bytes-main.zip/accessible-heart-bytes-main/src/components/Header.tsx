import { Link } from "@tanstack/react-router";

export function Header() {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-border/50 bg-background/80 backdrop-blur-md">
      <nav aria-label="Main Navigation" className="mx-auto flex max-w-5xl items-center justify-between px-4 py-4">
        <Link to="/" className="text-xl font-bold tracking-tight text-foreground transition-colors hover:text-primary">
          John Doe
        </Link>
        <ul className="flex items-center gap-6">
          <li>
            <Link
              to="/"
              activeProps={{ className: "text-primary font-medium" }}
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              Home
            </Link>
          </li>
          <li>
            <Link
              to="/about"
              activeProps={{ className: "text-primary font-medium" }}
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              About
            </Link>
          </li>
          <li>
            <Link
              to="/projects"
              activeProps={{ className: "text-primary font-medium" }}
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              Projects
            </Link>
          </li>
          <li>
            <Link
              to="/contact"
              activeProps={{ className: "text-primary font-medium" }}
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              Contact
            </Link>
          </li>
        </ul>
      </nav>
    </header>
  );
}
