export function Footer() {
  return (
    <footer className="border-t border-border/50 bg-background">
      <div className="mx-auto max-w-5xl px-4 py-8">
        <p className="text-center text-sm text-muted-foreground">
          &copy; 2026 John Doe. All Rights Reserved.
        </p>
      </div>
    </footer>
  );
}
